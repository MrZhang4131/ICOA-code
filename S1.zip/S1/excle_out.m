% MATLAB脚本：批量计算各算法性能（修复版）

% ========== 配置区域 ==========
inputFolder = '.';  % 输入文件夹路径
outputFileName = '算法性能汇总.xlsx';  % 输出文件名

% 算法名称列表（将作为输出表的列名）
algorithmNames = {'ICOA', 'COA', 'SCA', 'WOA', 'HHO', 'WDO', 'PSO', 'APO', 'DBO', 'BKA'};

% 函数名称列表（F1-F10）
functionNames = strcat('F', string(1:10));
% =================================

fprintf('开始处理10个实验文件...\n');
fprintf('================================================\n');

% 初始化三维数组：[函数 x 算法 x 文件]
numFunctions = 10;
numAlgorithms = length(algorithmNames);
numFiles = 10;
allData = NaN(numFunctions, numAlgorithms, numFiles);

% 循环读取每个文件
for fileIdx = 1:numFiles
    fileName = fullfile(inputFolder, sprintf('AllBest%d.xlsx', fileIdx));
    
    if ~isfile(fileName)
        fprintf('⚠ 跳过: 文件不存在 %s\n', fileName);
        continue;
    end
    
    try
        % 读取Excel文件
        opts = detectImportOptions(fileName);
        data = readtable(fileName, opts);
        
        % 提取算法列数据
        for algoIdx = 1:numAlgorithms
            algoName = algorithmNames{algoIdx};
            
            if ismember(algoName, data.Properties.VariableNames)
                colData = data.(algoName);
                
                % 转换为数值类型
                if ~isnumeric(colData)
                    colData = str2double(colData);
                end
                
                % 存储到三维数组（取前10行F1-F10）
                if length(colData) >= numFunctions
                    allData(:, algoIdx, fileIdx) = colData(1:numFunctions);
                end
            end
        end
        
        fprintf('✓ 已加载 AllBest%d.xlsx\n', fileIdx);
        
    catch ME
        fprintf('✗ 处理 %s 时出错: %s\n', fileName, ME.message);
    end
end

% 计算跨文件的平均值（对10个实验文件求平均）
avgData = mean(allData, 3, 'omitnan');  % 结果：10个函数 × 10个算法

% 计算每个算法的总平均值
overallMean = mean(avgData, 1, 'omitnan');  % 1 × 10 的行向量

% **修复：创建完整表格，包含函数行和平均值行**
rowNames = [functionNames' ; {'平均值'}];  % 11行
resultTable = table('Size', [numFunctions+1, numAlgorithms], ...
    'VariableNames', algorithmNames, ...
    'RowNames', rowNames);

% 填充F1-F10的数据行
resultTable(1:numFunctions, :) = array2table(avgData, 'VariableNames', algorithmNames);

% 填充最后一行（平均值行）
resultTable{'平均值', :} = overallMean;

% 保存到Excel
writetable(resultTable, outputFileName);

% 显示结果
fprintf('================================================\n');
fprintf('✓ 汇总完成！结果已保存到 "%s"\n', outputFileName);
fprintf('✓ 表格结构：算法名为列标题，函数F1-F10及平均值作为行\n\n');
disp(resultTable);

% 找出最优算法（最小值）
[bestValue, bestIdx] = min(overallMean);
fprintf('\n🏆 最优算法: %s (总平均值: %.6f)\n', algorithmNames{bestIdx}, bestValue);