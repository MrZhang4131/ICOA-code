function [time,Best_pos,Best_score,  Convergence_curve,input1,input2] = APO(N,dim,ub,lb,fobj,T,input1,input2)
% Arctic Puffin Optimization (APO) Algorithm
% fobj: objective function handle
% dim: dimension of the problem
% N: population size (N)
% T: maximum iterations (T)
% lb, ub: lower and upper bounds (vectors or scalars)
tic;
Convergence_curve = zeros(1, T);
t = 1;
if numel(lb) == 1
    lb = lb * ones(1, dim);
    ub = ub * ones(1, dim);
end

% Parameters
F = 0.5;  % Cooperative factor
C = 0.5;  % Threshold for behavior conversion

% Initialize population
Positions = zeros(N, dim);
for i = 1:N
    Positions(i, :) = lb + (ub - lb) .* rand(1, dim);
end
Best_score = inf;
best_idx = 0;
% Evaluate initial population
Fitness = zeros(N, 1);
for i = 1:N
    if Best_score > fobj(Positions(i, :))
        Best_score =  fobj(Positions(i, :));
        best_idx = i;
    end
    Convergence_curve(t) =    Best_score;
    t = t+1;
end

% Find initial best
% [Best_score, best_idx] = min(Fitness);
% Best_pos = Positions(best_idx, :);

Best_pos = Positions(1,:);


while t < T
    % Calculate behavior conversion factor B
    rnd = rand();
    B = 2 * log(1 / rnd) * (1 - t / T);

    new_Positions = zeros(N, dim);
    new_Fitness = zeros(N, 1);

    if B > C  % Exploration phase: Aerial flight
        candidates_Pos = zeros(2 * N, dim);
        candidates_Fit = zeros(2 * N, 1);

        for i = 1:N
            % Aerial search: Eq(2)
            r = randi([1, N]);
            while r == i
                r = randi([1, N]);
            end
            L = Levy(dim);
            alpha = randn();
            R = round(0.5 * (0.05 + rand())) * alpha;
            Y = Positions(i, :) + (Positions(i, :) - Positions(r, :)) .* L + R;

            % Swoop predation: Eq(5)
            S = tan((rand() - 0.5) * pi);
            Z = Y * S;

            % Bound check
            Y = max(min(Y, ub), lb);
            Z = max(min(Z, ub), lb);

            candidates_Pos(2*i-1, :) = Y;
            candidates_Pos(2*i, :) = Z;
            candidates_Fit(2*i-1) = fobj(Y);
            if Best_score> fobj(Y)
                Best_score =  fobj(Y);
            end
            Convergence_curve(t) =    Best_score;
            t = t+1;
            
            if t >=T
                break;
            end

            candidates_Fit(2*i) = fobj(Z);
            if Best_score> fobj(Z)
                Best_score =  fobj(Z);
            end
            Convergence_curve(t) =    Best_score;
            t = t+1;
            if t >=T
                break;
            end
        end

        % Sort and select top N: Eq(7-9)
        [sorted_Fit, sort_idx] = sort(candidates_Fit);
        new_Positions = candidates_Pos(sort_idx(1:N), :);
        new_Fitness = sorted_Fit(1:N);

    else  % Exploitation phase: Underwater foraging
        candidates_Pos = zeros(3 * N, dim);
        candidates_Fit = zeros(3 * N, 1);

        for i = 1:N
            % Gather foraging: Eq(10)
            r1 = randi([1, N]);
            r2 = randi([1, N]);
            r3 = randi([1, N]);
            while r1 == r2 || r1 == r3 || r2 == r3 || r1 == i || r2 == i || r3 == i
                r1 = randi([1, N]);
                r2 = randi([1, N]);
                r3 = randi([1, N]);
            end
            if rand() >= 0.5
                L = Levy(dim);
                W = Positions(r1, :) + F * L .* (Positions(r2, :) - Positions(r3, :));
            else
                W = Positions(r1, :) + F * (Positions(r2, :) - Positions(r3, :));
            end

            % Intensify search: Eq(11)
            f = 0.1 * (rand() - 1) * (T - t) / T;
            Y = W * (1 + f);

            % Avoid predators: Eq(13)
            r1 = randi([1, N]);
            r2 = randi([1, N]);
            while r1 == r2 || r1 == i || r2 == i
                r1 = randi([1, N]);
                r2 = randi([1, N]);
            end
            if rand() >= 0.5
                L = Levy(dim);
                Z = Positions(i, :) + F * L .* (Positions(r1, :) - Positions(r2, :));
            else
                beta = rand();
                Z = Positions(i, :) + beta * (Positions(r1, :) - Positions(r2, :));
            end

            % Bound check
            W = max(min(W, ub), lb);
            Y = max(min(Y, ub), lb);
            Z = max(min(Z, ub), lb);

            candidates_Pos(3*i-2, :) = W;
            candidates_Pos(3*i-1, :) = Y;
            candidates_Pos(3*i, :) = Z;
            candidates_Fit(3*i-2) = fobj(W);
            if Best_score> fobj(W)
                Best_score =  fobj(W);
            end
            Convergence_curve(t) =    Best_score;
            t = t+1;
            if t >=T
                break;
            end

            candidates_Fit(3*i-1) = fobj(Y);
            if Best_score> fobj(Y)
                Best_score =  fobj(Y);
            end
            Convergence_curve(t) =    Best_score;
            t = t+1;
            if t >=T
                break;
            end
            candidates_Fit(3*i) = fobj(Z);
            if Best_score> fobj(Z)
                Best_score =  fobj(Z);
            end
            Convergence_curve(t) =    Best_score;
            t = t+1;
            if t >=T
                break;
            end
        end

        if t >=T
            break;
        end
        
        % Sort and select top N: Eq(14-16)
        [sorted_Fit, sort_idx] = sort(candidates_Fit);
        new_Positions = candidates_Pos(sort_idx(1:N), :);
        new_Fitness = sorted_Fit(1:N);

    end

    if t >=T
        break;
    end

    % Update population
    Positions = new_Positions;
    Fitness = new_Fitness;

    % Update best
    % [current_best, best_idx] = min(Fitness);
    % if current_best < Best_score
    %     Best_score = current_best;
    %     Best_pos = Positions(best_idx, :);
    % end

    % Convergence_curve(t+1) = Best_score;
    % t = t + 1;
    
end
    time = toc;
end

function levy = Levy(d)
beta = 1.5;
sigma = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2^((beta - 1) / 2)))^(1 / beta);
u = randn(1, d) * sigma;
v = randn(1, d);
step = u ./ abs(v).^(1 / beta);
levy = 0.01 * step;
end