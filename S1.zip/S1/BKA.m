function [time, Best_pos,Best_score, BKA_curve,input1,input2] = BKA(N,dim,ub,lb,fobj,T,input1,input2)
tic;
t=1;
% Handle bounds as vectors
if length(lb) == 1
    lb = lb * ones(1, dim);
end
if length(ub) == 1
    ub = ub * ones(1, dim);
end
index = 0;
BKA_curve = zeros(1, T);
Best_score = inf;
% Initialization
Positions = zeros(N, dim);
for i = 1:N
    Positions(i, :) = lb + rand(1, dim) .* (ub - lb);
end

fitness = zeros(N, 1);
for i = 1:N
    if Best_score> fobj(Positions(i, :))
        Best_score =  fobj(Positions(i, :));
        index = i;
    end
    BKA_curve(t) =    Best_score;
    t = t+1;
end
Best_pos = Positions(100, :);
Leader_pos = Best_pos;
Leader_score = Best_score;



p = 0.9;  % Constant from paper
t=1;
while (t<=T)
    n = 0.05 * exp(-2 * (t / T)^2);
    
    for i = 1:N
        % Attacking behavior
        r = rand();
        for j = 1:dim
            if p < r  % Exploration branch (big perturbation)
                Positions(i, j) = Positions(i, j) + n * (1 + sin(rand())) * Positions(i, j);
            else  % Exploitation branch (small perturbation)
                Positions(i, j) = Positions(i, j) + n * (2 * rand() - 1) * Positions(i, j);
            end
        end

        % Clamp to bounds
        Positions(i, :) = max(min(Positions(i, :), ub), lb);

        % Migration behavior
        % Compute current fitness (after attacking)
        F_i = fobj(Positions(i, :));

        if Leader_score> F_i
            Leader_score =  F_i;
        end
        BKA_curve(t) =    Leader_score;
        t = t+1;

        if t >=T
            break;
        end

        % Generate random position and its fitness
        random_pos = lb + rand(1, dim) .* (ub - lb);
        F_ri = fobj(random_pos);
        if Leader_score> F_ri
            Leader_score =  F_ri;
        end
        BKA_curve(t) =    Leader_score;
        t = t+1;


        if t >=T
            break;
        end
        
        r = rand();
        m = 2 * sin(r + pi / 2);
        c = tan(pi * (rand() - 0.5));  % Cauchy(0,1)
        
        for j = 1:dim
            if F_i < F_ri
                Positions(i, j) = Positions(i, j) + c * abs(Positions(i, j) - Leader_pos(j));
            else
                Positions(i, j) = Positions(i, j) + c * abs(Leader_pos(j) - m * Positions(i, j));
            end
        end
        
        % Clamp to bounds
        Positions(i, :) = max(min(Positions(i, :), ub), lb);
        
        % Update fitness
        fitness(i) = fobj(Positions(i, :));

        if Leader_score> fitness(i)
            Leader_score =  fitness(i);
        end
        BKA_curve(t) =    Leader_score;
        t = t+1;

        if t >=T
            break;
        end

    end
    if t >=T
        break;
    end

    % Update leader if better found
    [current_best, index] = min(fitness);
    if current_best < Leader_score
        Leader_score = current_best;
        Leader_pos = Positions(index, :);
    end
    
    BKA_curve(t) = Leader_score;
    t=t+1;
end

Best_score = Leader_score;
Best_pos = Leader_pos;
time = toc;
end