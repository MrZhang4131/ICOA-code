
clc;
clear;
close all;
tic;

%测试基准
%5800H:
% 单核12s
% 8175M:
% 单线程20s
% 参数设定
pop = 100; % 种群数量
D = 50; % 维度
ub = 100 * ones(1, D); % 上界
lb = -100 * ones(1, D); % 下界
epoch = 30; % 轮次
maxIter = D*10000; % 最大迭代次数

core_num = 16;

dim = D;
[lb, ub, dim, fobj] = Get_Functions_cec2020(1, dim);
maxIter = dim * 10000;
disp(['测试函数', func2str(fobj)]);
% APO(pop, dim, ub, lb, fobj, maxIter, 1, 1);
toc
tic;
[time,Best_Pos,Best_fitness,IterCurve,input1,input2] = GWO(pop, dim, ub, lb, fobj, maxIter, 1, 1);
single_time = toc;
disp("单线程时长:" + num2str(single_time));

tic;
for i = 1:1
    SCA(pop, dim, ub, lb, fobj, maxIter, 1, 1);
end
ten_cycle = toc;
disp("单线程循环时长:" + num2str(ten_cycle));

% 获取当前并行池，若没有则创建一个（根据系统核数调整 numThreads）
pool = gcp('nocreate');
if isempty(pool)
    pool = parpool('local',core_num); % 或者 parpool('local', numThreads)
end

tic;
parfor i = 1:5*core_num
    ICOA(pop, dim, ub, lb, fobj, maxIter, 1, 1);
end
par_time = toc;
disp("多线程时长:" + num2str(par_time));



function [time,best_position,best_fun,cuve_f,input1,input2]  =ICOA(N,dim,ub,lb,fobj,T,input1,input2)
%% Define Parameters
cuve_f=zeros(1,T);
X=sobol_initialization(N,ub,lb,dim); %Initialize population
global_Cov = zeros(1,T);
Best_fitness = inf;
best_position = zeros(1,dim);
fitness_f = zeros(1,N);
for i=1:N
    fitness_f(i) =  fobj(X(i,:)); %Calculate the fitness value of the function
    if fitness_f(i)<Best_fitness
        Best_fitness = fitness_f(i);
        best_position = X(i,:);
    end
end
global_position = best_position;
global_fitness = Best_fitness;
cuve_f(1)=Best_fitness;
t=1;
while(t<=T)
    C = 2-(t/T); %Eq.(7)
    temp = rand*15+20; %Eq.(3)
    xf = (best_position+global_position)/2; % Eq.(5)
    Xfood = best_position;
    for i = 1:N
        if temp>30
            %% summer resort stage
            if rand<0.5
                Xnew(i,:) = X(i,:)+C*rand(1,dim).*(xf-X(i,:)); %Eq.(6)

            else
                if rand < 0.3
                    % 竞争阶段
                    beta = 1 - exp(-t / T);  % 动态调整系数
                    distances = sum((X - X(i,:)).^2, 2);  % 计算欧几里得距离
                    fitness_scores = fitness_f / max(fitness_f);  % 归一化适应度
                    historical_influence = beta * fitness_f;
                    combined_scores = historical_influence + distances;
                    [~, sorted_indices] = sort(combined_scores);

                    while true
                        % 选择一个具有较高综合评分的个体进行竞争
                        z = sorted_indices(randi([2, ceil(N / 2)]));  % 排除自己
                        if z ~= i
                            break;
                        end
                    end

                    for j = 1:dim
                        Xnew(i,j) = X(i,j) - X(z,j) + xf(j);  % Eq.(8)
                    end
                else
                    for j = 1:dim
                        z = round(rand*(N-1))+1;  %Eq.(9)
                        Xnew(i,j) = X(i,j)-X(z,j)+xf(j);  %Eq.(8)
                    end
                end
            end
        else
            %% foraging stage
            P = 3*rand*fitness_f(i)/fobj(Xfood); %Eq.(4)
            if P>2   % The food is too big
                Xfood = exp(-1/P).*Xfood;   %Eq.(12)
                for j = 1:dim
                    Xnew(i,j) = X(i,j)+cos(2*pi*rand)*Xfood(j)*p_obj(temp)-sin(2*pi*rand)*Xfood(j)*p_obj(temp); %Eq.(13)
                end
            else
                %                 Xnew(i,:) = (X(i,:)-Xfood)*p_obj(temp)+p_obj(temp).*rand(1,dim).*X(i,:); %Eq.(14)
                Xnew(i,:) = (X(i,:) -Xfood)*p_obj(temp) +p_obj(temp).*Levy().*X(i,:); % Levy Flight
            end
        end
    end
    %% boundary conditions
    for i=1:N
        for j =1:dim
            if length(ub)==1
                Xnew(i,j) = min(ub,Xnew(i,j));
                Xnew(i,j) = max(lb,Xnew(i,j));
            else
                Xnew(i,j) = min(ub(j),Xnew(i,j));
                Xnew(i,j) = max(lb(j),Xnew(i,j));
            end
        end
    end

    global_position = Xnew(1,:);
    global_fitness = fobj(global_position);

    for i =1:N
        %% Obtain the optimal solution for the updated population
        new_fitness = fobj(Xnew(i,:));
        if new_fitness<global_fitness
            global_fitness = new_fitness;
            global_position = Xnew(i,:);
        end
        %% Update the population to a new location
        if new_fitness<fitness_f(i)
            fitness_f(i) = new_fitness;
            X(i,:) = Xnew(i,:);
            if fitness_f(i)<Best_fitness
                Best_fitness=fitness_f(i);
                best_position = X(i,:);
            end
        end
        cuve_f(t) = Best_fitness;
        t=t+1;
    end
    global_Cov(t) = global_fitness;

    if mod(t,50)==0
        %       disp("COA"+"iter"+num2str(t)+": "+Best_fitness);
    end
end
best_fun = Best_fitness;
time = 1;
end
function y = p_obj(x)   %Eq.(4)
y = 0.2*(1/(sqrt(2*pi)*3))*exp(-(x-25).^2/(2*3.^2));
end

function result = Levy()
%LEVY 此处显示有关此函数的摘要
%   此处显示详细说明
% 生成服从 Levy 分布的随机步长
% alpha 是分布的指数，通常在 (0, 2] 范围内
alpha=0.8;
u = randn();
v = randn();
sigma_u = gamma(1 + alpha) * sin(pi * alpha / 2) / (gamma((1 + alpha) / 2) * alpha * 2^((alpha - 1) / 2));
sigma_v = 1;
result = sigma_u * (u / abs(v))^(1/alpha) * sign(u);
end

function X = sobol_initialization(N, ub, lb, dim)
    p = sobolset(dim); % 创建Sobol序列生成器
    X = net(p, N); % 生成N个dim维的Sobol点
    X = bsxfun(@plus, lb, bsxfun(@times, X, (ub - lb))); % 缩放到 [lb, ub] 范围内
end

