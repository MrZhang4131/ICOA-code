function cdplot(ranks, CD, labels, varargin)
% 简易 CD 图
n   = numel(ranks);
[srt, idx] = sort(ranks);
labels = labels(idx);
y    = 1:n;
clf; hold on; grid off;
plot(srt, y, 'ko', 'MarkerSize', 8, 'LineWidth', 1.2);
for i = 1:n
    plot([srt(i)-CD/2 srt(i)+CD/2], [y(i) y(i)], 'k-', 'LineWidth', 1.5);
end
xlabel('Average Rank'); ylabel('Algorithm');
set(gca,'YTick',y,'YTickLabel',labels,'FontName',getvar(varargin,'FontName','Arial'));
title('Critical-Difference (CD) Diagram');
xlim([min(srt)-CD max(srt)+CD]);
end

function val = getvar(pairs, key, default)
val = default;
for i = 1:2:numel(pairs)
    if strcmp(pairs{i}, key)
        val = pairs{i+1}; return
    end
end
end