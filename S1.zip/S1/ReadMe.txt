run CEC2020_8par_update4 or CEC2019_8par_update5
start parallel pool before running