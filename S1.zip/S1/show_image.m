%% 阶段1：逐张显示CEC2020 D=20的1.fig图片
clear; clc;

% 设置根目录（你的实际路径）
root_dir = ['C:\Users\31283\Desktop\PLOS One ICAO Test 2025.11.8\PLOS One ICAO Test 2025.11.3\PLOS One ICAO Test 2025.11.3\Result_Image' ...
    ''];

if ~exist(root_dir, 'dir')
    error('路径不存在，请检查:\n%s', root_dir);
end

% 查找所有 D=20 文件夹
folder_list = dir(fullfile(root_dir, 'CEC2020*维度=20*'));
folder_list = folder_list([folder_list.isdir]);
fig_count = length(folder_list);

if fig_count == 0
    error('未找到任何CEC2020 D=20文件夹');
end

% 预存储文件夹信息
folder_info = struct('index', {}, 'name', {}, 'path', {}, 'timestamp', {});

fprintf('【开始逐张展示】共发现 %d 个结果文件夹\n', fig_count);
fprintf('==============================================\n');

% 循环逐个打开图片
for i = 1:fig_count
    folder_path = fullfile(root_dir, folder_list(i).name);
    fig_file = fullfile(folder_path, '10.fig');
    
    % 存储信息
    folder_info(i).index = i;
    folder_info(i).name = folder_list(i).name;
    folder_info(i).path = folder_path;
    
    % 提取时间戳
    t_start = strfind(folder_list(i).name, 'T');
    t_end = strfind(folder_list(i).name, '维度');
    if ~isempty(t_start) && ~isempty(t_end)
        folder_info(i).timestamp = folder_list(i).name(t_start(1)+1 : t_end(1)-1);
    else
        folder_info(i).timestamp = 'N/A';
    end
    
    if exist(fig_file, 'file')
        fprintf('【%d/%d】显示: %s\n', i, fig_count, folder_info(i).timestamp);
        figure; % 新建图形窗口
        src_fig = openfig(fig_file, 'visible'); % 直接打开显示
        
        % 设置窗口标题
        set(src_fig, 'Name', sprintf('图 %d/%d: %s', i, fig_count, folder_info(i).timestamp));
        
        fprintf('   按任意键继续下一张...\n');
        pause;  % 等待用户按键
        close(src_fig);  % 关闭当前图片
    else
        warning('【%d/%d】文件不存在: %s', i, fig_count, fig_file);
        folder_info(i).timestamp = 'N/A';
    end
end

fprintf('\n所有图片已浏览完毕！\n');
fprintf('==============================================\n');

%% 阶段2：等待用户输入选择
while true
    % 修复错误：使用方括号拼接字符串
    user_input = input(['请输入要选择的图片索引 (1-' num2str(fig_count) '): '], 's');
    selected_idx = str2double(user_input);
    
    if isnumeric(selected_idx) && selected_idx >= 1 && selected_idx <= fig_count
        fprintf('✓ 已选择索引 %d: %s\n', selected_idx, folder_info(selected_idx).name);
        break;
    else
        fprintf('✗ 无效输入！请输入 1 到 %d 之间的数字\n', fig_count);
    end
end

%% 阶段3：复制mat文件到新文件夹
output_dir = fullfile(root_dir, sprintf('Selected_F1_Data_%s', folder_info(selected_idx).timestamp));
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

fprintf('\n创建目标文件夹: %s\n', output_dir);

mat_filename = 'AllCurve_F10.mat';
source_mat = fullfile(folder_info(selected_idx).path, mat_filename);

if exist(source_mat, 'file')
    target_mat = fullfile(output_dir, mat_filename);
    copyfile(source_mat, target_mat);
    fprintf('✓ 成功复制 %s\n', mat_filename);
    fprintf('   目标路径: %s\n', target_mat);
else
    warning('未找到标准文件: %s\n正在查找替代文件...', mat_filename);
    all_mats = dir(fullfile(folder_info(selected_idx).path, '*Curve*F1*.mat'));
    
    if ~isempty(all_mats)
        fprintf('发现: %s -> 已复制\n', all_mats(1).name);
        copyfile(fullfile(folder_info(selected_idx).path, all_mats(1).name), ...
                fullfile(output_dir, all_mats(1).name));
    else
        error('该文件夹下未找到任何匹配的mat文件！');
    end
end

fprintf('\n操作完成！请查看文件夹:\n%s\n', output_dir);






