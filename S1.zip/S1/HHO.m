function [time, Rabbit_Location, Rabbit_Energy, CNVG,input1,input2] = HHO(N, dim, ub, lb, fobj, T,input1,input2)
    tic;
    % disp('HHO is now tackling your problem')

    % Initialize the location and Energy of the rabbit
    Rabbit_Location = zeros(1, dim);
    Rabbit_Energy = inf;

    % Initialize the locations of Harris' hawks
    X = initialization(N, dim, ub, lb);

    CNVG = zeros(1, T);

    t = 1; % Loop counter

    while t <= T
        for i = 1:size(X, 1)
            % Check boundaries
            X(i, :) = max(min(X(i, :), ub), lb);
            
            % Fitness of locations
            fitness = fobj(X(i, :));

            % Update the location of Rabbit
            if fitness < Rabbit_Energy
                Rabbit_Energy = fitness;
                Rabbit_Location = X(i, :);
            end

            CNVG(t) = Rabbit_Energy;
            t = t + 1;
            if t > T
                break;
            end
        end
        if t > T
            break;
        end
        E1 = 2 * (1 - (t / T)); % factor to show the decreasing energy of rabbit

        % Update the location of Harris' hawks
        for i = 1:size(X, 1)
            E0 = 2 * rand() - 1; %-1<E0<1
            Escaping_Energy = E1 * E0;  % escaping energy of rabbit

            if abs(Escaping_Energy) >= 1
                % Exploration:
                % Harris' hawks perch randomly based on 2 strategies:

                q = rand();
                rand_Hawk_index = floor(N * rand() + 1);
                X_rand = X(rand_Hawk_index, :);
                if q < 0.5
                    % Perch based on other family members
                    X(i, :) = X_rand - rand() * abs(X_rand - 2 * rand() * X(i, :));
                else
                    % Perch on a random tall tree (random site inside group's home range)
                    X(i, :) = (Rabbit_Location(1, :) - mean(X)) - rand() * ((ub - lb) * rand() + lb);
                end

            elseif abs(Escaping_Energy) < 1
                % Exploitation:
                % Attacking the rabbit using 4 strategies regarding the behavior of the rabbit

                % Phase 1: surprise pounce (seven kills)
                % surprise pounce (seven kills): multiple, short rapid dives by different hawks

                r = rand(); % probability of each event

                if r >= 0.5 && abs(Escaping_Energy) < 0.5 % Hard besiege
                    X(i, :) = Rabbit_Location - Escaping_Energy * abs(Rabbit_Location - X(i, :));
                elseif r >= 0.5 && abs(Escaping_Energy) >= 0.5  % Soft besiege
                    Jump_strength = 2 * (1 - rand()); % random jump strength of the rabbit
                    X(i, :) = (Rabbit_Location - X(i, :)) - Escaping_Energy * abs(Jump_strength * Rabbit_Location - X(i, :));
                elseif r < 0.5 && abs(Escaping_Energy) >= 0.5  % Soft besiege
                    % Rabbit tries to escape by many zigzag deceptive motions
                    Jump_strength = 2 * (1 - rand());
                    X1 = Rabbit_Location - Escaping_Energy * abs(Jump_strength * Rabbit_Location - X(i, :));
                    X1 = max(min(X1, ub), lb);
                    if fobj(X1) < fobj(X(i, :)) % Improved move?
                        if fobj(X1) < Rabbit_Energy
                            Rabbit_Energy = fobj(X1);
                        end
                        X(i, :) = X1;
                    else % Hawks perform levy-based short rapid dives around the rabbit
                        X2 = Rabbit_Location - Escaping_Energy * abs(Jump_strength * Rabbit_Location - X(i, :)) + rand(1, dim) .* Levy(dim);
                        X2 = max(min(X2, ub), lb);
                        if fobj(X2) < fobj(X(i, :)) % Improved move?
                            if fobj(X2) < Rabbit_Energy
                                Rabbit_Energy = fobj(X2);
                            end
                            X(i, :) = X2;
                        end
                    end
                elseif r < 0.5 && abs(Escaping_Energy) < 0.5 % Hard besiege
                    % Rabbit tries to escape by many zigzag deceptive motions
                    % Hawks try to decrease their average location with the rabbit
                    Jump_strength = 2 * (1 - rand());
                    X1 = Rabbit_Location - Escaping_Energy * abs(Jump_strength * Rabbit_Location - mean(X));
                    X1 = max(min(X1, ub), lb);
                    if fobj(X1) < fobj(X(i, :)) % Improved move?
                        if fobj(X1) < Rabbit_Energy
                            Rabbit_Energy = fobj(X1);
                        end
                        X(i, :) = X1;
                    else % Perform levy-based short rapid dives around the rabbit
                        X2 = Rabbit_Location - Escaping_Energy * abs(Jump_strength * Rabbit_Location - mean(X)) + rand(1, dim) .* Levy(dim);
                        X2 = max(min(X2, ub), lb);
                        if fobj(X2) < fobj(X(i, :)) % Improved move?
                            if fobj(X2) < Rabbit_Energy
                                Rabbit_Energy = fobj(X2);
                            end
                            X(i, :) = X2;
                        end
                    end
                end
                if t > T
                    break;
                end
            end
            if t > T
                break;
            end
        end
        if t > T
            break;
        end

        % Print the progress every 100 iterations
        % if mod(t, 100) == 0
        %     disp(['At iteration ', num2str(t), ' the best fitness is ', num2str(Rabbit_Energy)]);
        % end
    end
       time = toc;
end

% Initialization function
function X = initialization(N, dim, ub, lb)
    X = rand(N, dim) .* (ub - lb) + lb;
end

% Levy function
function o = Levy(d)
    beta = 1.5;
    sigma = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2 ^ ((beta - 1) / 2))) ^ (1 / beta);
    u = randn(1, d) * sigma;
    v = randn(1, d);
    step = u ./ abs(v).^(1 / beta);
    o = step;
end
