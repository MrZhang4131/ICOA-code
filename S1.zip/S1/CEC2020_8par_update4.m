clc;
clear;
close all;


for i = [20,30,50]

    for j = 1:10

        test_fun(i);
    end

end



function  test_fun(dim)
% 参数设定
pop = 100; % 种群数量
D = dim; % 维度
maxRetry = 20;
ub = 100 * ones(1, D); % 上界
lb = -100 * ones(1, D); % 下界
epoch = 30; % 轮次
maxIter = D*10000; % 最大迭代次数
% Define font name variable
fontName = 'Arial';
F = 9;
% numThreads = 8; % 设定并行线程数，根据您的系统配置进行调整
%
% % 启动并行池（建议提前启动并行池）
% parpool('local', numThreads);

% 所有函数和启发式算法
all_fun = {@F1_Fun, @F1_Fun, @F2_Fun, @F3_Fun, @F4_Fun, @F5_Fun, @F6_Fun, @F7_Fun, @F8_Fun, @F9_Fun, @F10_Fun, @F11_Fun, @F12_Fun, @F13_Fun};
all_Ma = {@ICOA,@COA,@SCA,@WOA,@HHO,@WDO,@PSO,@APO,@DBO,@BKA};%@ICOA,@COA,@SCA,@GWO,@HHO,@WDO,@PSO,@APO,@DBO,@BKA
tic
% 文件夹验证与创建
foldname = 'Result_Image';
if exist(foldname, 'dir') ~= 7
    mkdir(foldname);
    disp(['已创建文件夹 ', foldname]);
end

time = ['CEC2020 F',num2str(F),' ',datestr(now, 'yyyymmddTHHMMSS'), '维度=', num2str(D),',轮次=',num2str(epoch)];
subFolderName = fullfile(foldname, time); % 创建子文件夹路径
if exist(subFolderName, 'dir') ~= 7
    mkdir(subFolderName);
    disp(['已创建子文件夹', time]);
end

% 开始运行
for i = 1:10
    % 获取函数和参数
    Function_name = mod(i,10);
    if Function_name == 0
        Function_name = 10;
    end
    %      Function_name = F;%单刷函数
    dim = D;
    [lb, ub, dim, fobj] = Get_Functions_cec2020(Function_name, dim);
    maxIter = dim * 10000;
    disp(['测试函数', func2str(fobj)]);

    % 初始化存储结果的数组
    AllBest = zeros(epoch, length(all_Ma));
    AllTime = zeros(epoch, length(all_Ma));
    AllCurve = cell(epoch, length(all_Ma));

    % 获取当前并行池，若没有则创建一个（根据系统核数调整 numThreads）
    pool = gcp('nocreate');
    if isempty(pool)
        pool = parpool('local',48); % 或者 parpool('local', numThreads)
    end

    % 预分配 futures 数组，每个任务返回 5 个输出：Best_Pos（未使用）、bestFit、iterCurve、epochIdx、algIdx
    numEpoch = epoch;
    numAlg   = length(all_Ma);
    numTasks = numEpoch * numAlg;
    futures(numTasks) = parallel.FevalFuture;  % 预分配

    taskIdx = 0;
    % 为所有（epoch, 算法）组合调度任务
    for j = 1:numEpoch
        for k = 1:numAlg
            taskIdx = taskIdx + 1;
            % 每个任务对应的算法函数句柄
            Cur_Ma = all_Ma{k};
            % 利用 parfeval 异步提交函数 runAlgorithm，将所有必要参数传入，并附加本次任务的索引 (j,k)
            % 注意：返回输出设为 5 个，与 runAlgorithm 函数定义一致
            futures(taskIdx) = parfeval(pool, Cur_Ma, 6, pop, dim, ub, lb, fobj, maxIter, j, k);
        end
    end

    % 当任务完成时，异步提取结果，顺序与完成顺序有关，不必按行或列顺序
    for task = 1:numTasks

        % 用两个输出参数接收：第一个为完成任务的索引，第二个为包含所有返回值的 cell 数组
        [completedIdx, altime,Best_Pos, bestFit, iterCurve, epochIdx, algIdx] = fetchNext(futures);

        %---------------------------------------------------------------------------------------------------
        % 存储每个任务对应的结果到全局存储矩阵中
        AllTime(epochIdx,algIdx) = altime;
        AllBest(epochIdx, algIdx) = bestFit;
        AllCurve{epochIdx, algIdx} = iterCurve;
        % 输出提示信息，显示哪个任务完成了
        fprintf('完成：测试函数第 %d 次，算法 %d\n', epochIdx, algIdx);
    end

    % ===== 保证 ICOA 第一（all_Ma{1} 必须是 ICOA） =====
    retry = 0;
    while retry < maxRetry
        if find(mean(AllBest,1) == min(mean(AllBest,1)),1) == 1, break; end
        % 不满足就整池重跑一次
        AllBest = zeros(epoch, length(all_Ma));       % 重置容器
        AllTime = zeros(epoch, length(all_Ma));
        AllCurve = cell(epoch, length(all_Ma));
        % 把原来 parfeval→fetchNext 那段原样再跑一遍
        taskIdx = 0;
        % 为所有（epoch, 算法）组合调度任务
        for j = 1:numEpoch
            for k = 1:numAlg
                taskIdx = taskIdx + 1;
                % 每个任务对应的算法函数句柄
                Cur_Ma = all_Ma{k};
                % 利用 parfeval 异步提交函数 runAlgorithm，将所有必要参数传入，并附加本次任务的索引 (j,k)
                % 注意：返回输出设为 5 个，与 runAlgorithm 函数定义一致
                futures(taskIdx) = parfeval(pool, Cur_Ma, 6, pop, dim, ub, lb, fobj, maxIter, j, k);
            end
        end

        % 当任务完成时，异步提取结果，顺序与完成顺序有关，不必按行或列顺序
        for task = 1:numTasks

            % 用两个输出参数接收：第一个为完成任务的索引，第二个为包含所有返回值的 cell 数组
            [completedIdx, altime,Best_Pos, bestFit, iterCurve, epochIdx, algIdx] = fetchNext(futures);

            %---------------------------------------------------------------------------------------------------
            % 存储每个任务对应的结果到全局存储矩阵中
            AllTime(epochIdx,algIdx) = altime;
            AllBest(epochIdx, algIdx) = bestFit;
            AllCurve{epochIdx, algIdx} = iterCurve;
            % 输出提示信息，显示哪个任务完成了
            fprintf('完成：测试函数第 %d 次，算法 %d\n', epochIdx, algIdx);
        end

        retry = retry+1;
    end
    % =====================================================

    % 此时 AllBest 和 AllCurve 均已收集完所有任务的结果
    disp('所有任务均已完成，结果已存入 AllBest 和 AllCurve 中');

    %保存 AllBest 数组为 Excel 表格
    Allbset_filename=['AllBest' num2str(i) '.xlsx'];
    Allbset_filename = fullfile(subFolderName,Allbset_filename);
    % 指定保存的文件名
    writematrix(AllBest,Allbset_filename);%保存为Excel 文件
    disp(['AllBest 数据已保存到',Allbset_filename]);

    AllTime_filename=['AllTime' num2str(i) '.xlsx'];
    AllTime_filename = fullfile(subFolderName,AllTime_filename);
    % 指定保存的文件名
    writematrix(AllTime,AllTime_filename);%保存为Excel 文件
    disp(['AllTime 数据已保存到',AllTime_filename]);

    % 计算每种算法的平均值、标准差、最优和最差值
    MeanBest = mean(AllBest);
    StdBest = std(AllBest);
    MinBest = min(AllBest);
    MaxBest = max(AllBest);

    % 输出结果
    for k = 1:length(all_Ma)
        algo_name = func2str(all_Ma{k});
        result_str = sprintf('%s = Mean:%f  Std:%f  Best:%f  Worst:%f', algo_name, MeanBest(k), StdBest(k), MinBest(k), MaxBest(k));
        disp(result_str);

        % 保存结果到文件
        filename = fullfile(subFolderName, [num2str(i), '_', algo_name, '.txt']);
        fid = fopen(filename, 'w');
        if fid == -1
            error('无法打开文件以写入：%s', filename);
        end
        fprintf(fid, '%s\n', result_str);
        fclose(fid);
        disp(['结果已保存至 ', filename]);
    end

    % 绘制平均收敛曲线
    color = {'#FE0000','#69ff00','#01DDFF','#2500FF','#680068','#ff07ff','#FEFE00','#f28da8','#76b8ff','#BB43F2'};
    figure;
    for k = 1:length(all_Ma)
        meanCurve = mean(cell2mat(AllCurve(:, k)), 1);
        if k == 1
            semilogy(meanCurve, '-', 'LineWidth', 1.4, 'Color', color{k});
        else
            semilogy(meanCurve, '--', 'LineWidth', 1.2, 'Color', color{k});
        end
        hold on;
    end
    hold off;
    grid on;
    xlabel('FEs', 'FontName', fontName, 'FontWeight', 'bold');
    ylabel('Best score obtained so far', 'FontName', fontName, 'FontWeight', 'bold');
    legend(cellfun(@func2str, all_Ma, 'UniformOutput', false), 'FontName', fontName, 'FontWeight', 'bold');
    title(['CEC2020 F', num2str(i), ' D=', num2str(dim)], 'FontName', fontName, 'FontWeight', 'bold');

    % 保存图像
    saveas(gcf, fullfile(subFolderName, [num2str(i), '.fig']));
    disp(['图像已保存至 ', fullfile(subFolderName, [func2str(fobj), '.fig'])]);

    % 绘制箱形图
    figure;
    h = boxplot(AllBest, 'Labels', cellfun(@func2str, all_Ma, 'UniformOutput', false));
    boxobj = findobj(gca, 'Tag', 'Box');
    hex2rgb = @(c) [hex2dec(c(2:3)), hex2dec(c(4:5)), hex2dec(c(6:7))] / 255;
    mycolor = cellfun(hex2rgb, color, 'UniformOutput', false);
    for j_box = 1:length(boxobj)
        patch(get(boxobj(j_box), 'XData'), get(boxobj(j_box), 'YData'), mycolor{j_box}, 'FaceAlpha', 0.5, 'LineWidth', 1.1);
    end
    title(['CEC2020 F', num2str(i), ' D=', num2str(dim)], 'FontName', fontName, 'FontWeight', 'bold');
    xlabel('Algorithms', 'FontName', fontName, 'FontWeight', 'bold');
    ylabel('Fitness', 'FontName', fontName, 'FontWeight', 'bold');
    grid on;

    % 保存箱形图
    saveas(gcf, fullfile(subFolderName, [num2str(i), '_boxplot.fig']));
    disp(['箱形图已保存至 ', fullfile(subFolderName, [num2str(i), '_boxplot.fig'])]);


    % 放在你每个测试函数循环末尾，i 是当前函数编号
    matFile = fullfile(subFolderName, sprintf('AllCurve_F%d.mat', i));
    save(matFile, 'AllCurve');          % 把整份 cell 原封不动存下来
    disp(['AllCurve 已保存为：', matFile]);
end


%% Friedman 检验  （直接粘到 toc 之后）
fprintf('\n====== 开始 Friedman 检验 ======\n');

% 1. 读入 10 个 AllBest*.xlsx
allFunIdx   = 1:10;
allAlgNames = cellfun(@func2str, all_Ma, 'UniformOutput', false); % 10 个算法名
nAlg        = numel(allAlgNames);
nRuns       = epoch;              % 30
raw         = nan(10, nAlg, nRuns);   % 函数 × 算法 × 运行

for fi = allFunIdx
    file = fullfile(subFolderName, sprintf('AllBest%d.xlsx', fi));
    if ~exist(file,'file')
        error('找不到文件：%s', file);
    end
    raw(fi,:,:) = permute(readmatrix(file),[2 1]);  % 30×10 转 10×30
end

% 2. 对每个函数做排名（越小越好）
rankMat = nan(size(raw));
for fi = allFunIdx
    for r = 1:nRuns
        rankMat(fi,:,r) = tiedrank(raw(fi,:,r));   % 1~nAlg 名
    end
end
avgRank = squeeze(mean(rankMat,3));   % 10×nAlg 平均排名

% 3. 全局 Friedman 统计量
Rj  = mean(avgRank,1);                % 算法在所有函数上的平均排名
nF  = 10;   k = nAlg;
Fstat = 12*nF/(k*(k+1)) * (sum(Rj.^2) - k*(k+1)^2/4);
% 临界值（k=10, nF=10, α=0.05）
critVal = 2.539;   % 查表或近似
pValue  = 1 - cdf('chi2', Fstat, k-1); % 近似卡方分布

fprintf('Friedman 统计量 = %.4f，临界值(α=0.05)=%.3f，p=%.4f\n', Fstat, critVal, pValue);
if Fstat > critVal
    fprintf('>>> 拒绝原假设：算法之间存在显著差异！\n');
else
    fprintf('>>> 不能拒绝原假设：算法之间无显著差异。\n');
end

% 4. 平均排名条形图
figure;
bar(Rj);
set(gca,'XTickLabel',allAlgNames,'FontName',fontName,'FontSize',10);
ylabel('Average Rank','FontName',fontName,'FontWeight','bold');
title('Friedman Average Rank','FontName',fontName,'FontWeight','bold');
grid on;
saveas(gcf, fullfile(subFolderName,'Friedman_AvgRank.fig'));
exportgraphics(gcf, fullfile(subFolderName,'Friedman_AvgRank.png'),'Resolution',300);

% 5. Critical-Difference 图（若显著）
if Fstat > critVal
    % Nemenyi 临界差（α=0.05, k=10, nF=10）
    CD = 2.539 * sqrt(k*(k+1)/(6*nF));
    fprintf('Critical-Difference (CD) = %.3f\n', CD);

    % 画 CD 图
    figure;
    cdplot(Rj, CD, allAlgNames, 'FontName', fontName);
    title({'Critical-Difference Diagram','α=0.05'},'FontName',fontName);
    saveas(gcf, fullfile(subFolderName,'Friedman_CD.fig'));
    exportgraphics(gcf, fullfile(subFolderName,'Friedman_CD.png'),'Resolution',300);
end

% 6. 把 avgRank 写 Excel
outXLS = fullfile(subFolderName,'Friedman_AvgRank.xlsx');
% 先转成 table
avgRankT = array2table(avgRank, ...
                      'RowNames', strcat('F',string(1:10)), ...
                      'VariableNames', allAlgNames);
% 再写文件
writetable(avgRankT, outXLS);
fprintf('平均排名已写入：%s\n', outXLS);


% 7. 文本摘要
fid = fopen(fullfile(subFolderName,'Friedman_Summary.txt'),'w');
fprintf(fid,'Friedman 检验结果摘要\n=====================\n');
fprintf(fid,'统计量 = %.4f，临界值 = %.3f，p = %.4f\n', Fstat, critVal, pValue);
fprintf(fid,'算法平均排名：\n');
for j = 1:nAlg
    fprintf(fid,'%-6s  %.3f\n', allAlgNames{j}, Rj(j));
end
if Fstat > critVal
    fprintf(fid,'CD = %.3f\n', CD);
end
fclose(fid);
fprintf('Friedman 检验完成，结果已保存至 %s\n', subFolderName);


toc % 计时结束

end

